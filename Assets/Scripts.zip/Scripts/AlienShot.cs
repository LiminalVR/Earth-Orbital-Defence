﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlienShot : MonoBehaviour
{
    // Update is called once per frame
    
    
    

    
}
